<?php $__env->startSection("title"); ?>
<title>eBuloy</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div id="overlay"></div>

    <div class="wrapper">
        <div class="container">
            <div class="text-center pt-4">
                <img class="ebuloy-persian-green-img" src="<?php echo e(url("img/ebuloy-persian-green.png")); ?>" />
            </div>

            <div class="mt-5 mb-1 pt-3 pb-2">
                <p class="pages-header">Sign Up A<br>New Account</p>
            </div>

            <div class="pt-3 px-2">
                <button class="btn c-btn c-btn-5 mb-3">Facebook</button>
                <button class="btn c-btn c-btn-6 mb-3">Google</button>
                <button class="btn c-btn c-btn-3 mb-3">Email</button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/ebuloy/resources/views/pages/signup.blade.php ENDPATH**/ ?>